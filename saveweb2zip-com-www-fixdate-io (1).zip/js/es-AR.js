var lang_nombreRequerido = 'Ingrese nombre';
var lang_informandoAsistencia = 'Informando asistencia';
var lang_confirmarAsistencia = 'Enviar';

var lang_caracteresNombreAsistencia = 'El nombre no debe superar 20 caracteres';
var lang_caracteresComentariosAsistencia = 'El mensaje no debe superar 100 caracteres';

var lang_asistenciaMsjExito_1 = 'Información enviada';
var lang_asistenciaMsjExito_2 = 'Hemos enviado tu información de asistencia'; 


var lang_cancionRequerida = 'Ingrese nombre de canción / autor';
var lang_linkIncorrecto = 'Formato link incorrecto';
var lang_enviandoSugerencia = 'Enviando sugerencia';
var lang_sugerirCancion = 'Sugerir Canción';


var lang_caracteresNombreSugerencia = 'El nombre no debe superar 20 caracteres';
var lang_caracteresCancionSugerencia = 'El título / autor no debe superar 50 caracteres';
var lang_caracteresLinkSugerencia = 'El link no debe superar 250 caracteres';


var lang_sugerirCancionMsjExito_1 = 'Sugerencia enviada';
var lang_sugerirCancionMsjExito_2 = 'Tu sugerencia de canción se ha agregado a la lista';

var lang_titleModalAsistenciaCeremonia = '¿Asistes a la ceremonia?';
var lang_titleModalAsistenciaFiesta = '¿Asistes a la fiesta?';

var lang_titleModalMapaFiesta = 'Cómo llegar a la Fiesta';
var lang_titleModalMapaCeremonia = 'Cómo llegar a la Ceremonia';


var lang_codigoAccesoVipRequerido = 'Ingrese el código de acceso';
var lang_btnCodigoVip = 'Acceder';
var lang_accediendoCodigoVip = 'Accediendo';

var lang_textoFinalCuentaRegresiva = '¡LLEGO EL <br> GRAN DÍA!';


